// pages/index.js
export default function Home() {
  return <h1>Welcome to WealthSage</h1>;
}