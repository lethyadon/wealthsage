// components/NavBar.js
export default function NavBar() {
  return <nav>NavBar</nav>;
}